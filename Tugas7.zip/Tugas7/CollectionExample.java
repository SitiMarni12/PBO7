import java.util.ArrayList;
import java.util.ArrayDeque;

public class CollectionExample {
    
    public static void main(String[] args) {
        // Contoh penggunaan ArrayList dengan tipe data generik
        ArrayList<String> daftarNama = new ArrayList<>();
        daftarNama.add("Kyuhyun");
        daftarNama.add("Seohyun");
        daftarNama.add("Yoona");

        System.out.println("Daftar Nama:");
        for (String nama : daftarNama) {
            System.out.println(nama);
        }

        // Contoh penggunaan ArrayDeque dengan tipe data generik
        ArrayDeque<Integer> antrian = new ArrayDeque<>();
        antrian.add(1);
        antrian.add(2);
        antrian.add(3);

        System.out.println("\nAntrian:");
        for (int nomor : antrian) {
            System.out.println(nomor);
        }
    }
}
